/**
 * A test constructor.
 * @constructor
 * @ignore
 */
function Ignored() {
	/** a method */
    this.bar = function() {
    }
}